export default function ShopPage() {
  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold text-neutral-100">Shop</h1>
      <p className="text-xs text-neutral-400">
        This page will be expanded in later phases. Core auth & profile are already working.
      </p>
    </div>
  );
}\n