declare module "bcryptjs";
declare module "nodemailer";

// Add other third-party modules here that don't provide types yet.
