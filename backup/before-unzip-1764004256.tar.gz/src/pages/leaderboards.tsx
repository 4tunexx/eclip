export default function LeaderboardsPage() {
  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold text-neutral-100">Leaderboards</h1>
      <p className="text-xs text-neutral-400">
        This section will be expanded with full functionality (ranks, chat, shop, admin tools, etc.).
      </p>
    </div>
  );
}
