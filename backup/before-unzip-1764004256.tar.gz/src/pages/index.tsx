import Link from "next/link";
import { useEffect, useState } from "react";

type Stats = {
  onlinePlayers: number;
  liveMatches: number;
  finishedMatches: number;
  coinsEarned: number;
};

export default function HomePage() {
  const [stats, setStats] = useState<Stats | null>(null);

  useEffect(() => {
    fetch("/api/platform/stats")
      .then((r) => r.json())
      .then((data) => setStats(data))
      .catch(() => setStats(null));
  }, []);

  return (
    <div className="flex min-h-screen flex-col items-center justify-between px-4 py-6">
      <div className="w-full max-w-4xl space-y-8">
        <div className="flex items-center justify-center">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-md border border-accent-primary/40 bg-gradient-to-br from-accent-primary/50 to-accent-secondary/20" />
            <div className="text-xl font-semibold tracking-wide">
              <span className="text-accent-primary">Eclip</span>
              <span className="text-neutral-300">.pro</span>
            </div>
          </div>
        </div>
        <section className="rounded-2xl border border-white/10 bg-gradient-to-br from-[#020617] via-[#020A04] to-[#020617] p-6 shadow-[0_0_40px_rgba(0,0,0,0.8)]">
          <div className="space-y-4 text-center">
            <h1 className="text-3xl font-semibold text-neutral-100 sm:text-4xl">
              The CS2 competitive layer built for grinders.
            </h1>
            <p className="mx-auto max-w-2xl text-sm text-neutral-400">
              Queue into ranked, climb custom Eclip ranks, earn coins, unlock cosmetics,
              and flex your public profile.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4">
              <Link
                href="/login"
                className="rounded-lg bg-accent-primary px-5 py-2 text-sm font-semibold text-black shadow-[0_0_25px_rgba(123,255,90,0.7)] hover:bg-[#93FF7B] transition"
              >
                Login
              </Link>
              <Link
                href="/register"
                className="rounded-lg border border-white/15 bg-white/5 px-5 py-2 text-sm font-semibold text-neutral-100 hover:border-accent-primary/60 transition"
              >
                Register
              </Link>
              <a
                href="/api/auth/steam"
                className="inline-flex items-center gap-2 rounded-lg border border-[#66c0f4]/60 bg-[#1b2838] px-5 py-2 text-sm font-semibold text-[#c7d5e0] hover:bg-[#171a21] transition"
              >
                <span>Sign in with Steam</span>
              </a>
            </div>
          </div>
        </section>
        <section className="grid gap-3 text-xs sm:grid-cols-4">
          <div className="rounded-xl border border-white/10 bg-black/40 p-3">
            <p className="text-neutral-400">Players online</p>
            <p className="mt-1 text-2xl font-semibold text-neutral-100">
              {stats ? stats.onlinePlayers : "–"}
            </p>
          </div>
          <div className="rounded-xl border border-white/10 bg-black/40 p-3">
            <p className="text-neutral-400">Matches live</p>
            <p className="mt-1 text-2xl font-semibold text-neutral-100">
              {stats ? stats.liveMatches : "–"}
            </p>
          </div>
          <div className="rounded-xl border border-white/10 bg-black/40 p-3">
            <p className="text-neutral-400">Matches finished</p>
            <p className="mt-1 text-2xl font-semibold text-neutral-100">
              {stats ? stats.finishedMatches : "–"}
            </p>
          </div>
          <div className="rounded-xl border border-white/10 bg-black/40 p-3">
            <p className="text-neutral-400">Coins earned</p>
            <p className="mt-1 text-2xl font-semibold text-accent-gold">
              {stats ? stats.coinsEarned : "–"}
            </p>
          </div>
        </section>
      </div>
      <footer className="mt-8 w-full border-t border-white/10 py-4 text-center text-[11px] text-neutral-500">
        © {new Date().getFullYear()} Eclip.pro – Dominate • Win • Compete • Play • Enjoy
      </footer>
    </div>
  );
}
